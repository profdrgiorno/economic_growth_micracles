"""
===================================================================================
STOCHASTIC GROWTH MIRACLES & ENDOGENOUS PLANNER MODEL
Numerical Simulation Engine (Euler-Maruyama & Truncated Gamma Sampling)
Author: Prof. Joilson Giorno, Ph.D.
===================================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gamma

np.random.seed(42)

def truncated_gamma_pdf(x, alpha, beta, x_cap):
    scale = 1.0 / beta
    untruncated_pdf = gamma.pdf(x, a=alpha, scale=scale)
    cdf_cap = gamma.cdf(x_cap, a=alpha, scale=scale)
    return np.where(x <= x_cap, untruncated_pdf / cdf_cap, 0.0)

def drift_function(X, I, a=0.15, b=0.015, delta=0.05, lam=0.08, psi=0.6):
    return lam * I * (X**psi) - delta * X + a * (X**2) - b * (X**3)

def simulate_trajectories(I_val, T=80, dt=0.01, sigma=0.35, X0=1.0, num_paths=4):
    n_steps = int(T / dt)
    time_grid = np.linspace(0, T, n_steps)
    paths = np.zeros((num_paths, n_steps))
    for p in range(num_paths):
        X = np.zeros(n_steps)
        X[0] = X0
        for i in range(1, n_steps):
            dW = np.sqrt(dt) * np.random.normal()
            mu = drift_function(X[i-1], I=I_val)
            vol = sigma * np.sqrt(max(X[i-1], 0.0))
            X[i] = max(X[i-1] + mu * dt + vol * dW, 0.01)
        paths[p, :] = X
    return time_grid, paths

if __name__ == "__main__":
    print("Executing Stochastic Growth Simulation...")
    # Generate Figure 1
    fig1, ax1 = plt.subplots(figsize=(8, 4.5), dpi=300)
    x_grid = np.linspace(0.01, 30, 1000)
    regimes = [
        {"alpha": 3.0, "beta": 0.5, "cap": 11.0, "color": "#C0392B", "label": "Extractive Regime / Low I (Cap = 11)"},
        {"alpha": 5.0, "beta": 0.5, "cap": 17.0, "color": "#D35400", "label": "Transitional Governance (Cap = 17)"},
        {"alpha": 7.0, "beta": 0.5, "cap": 28.0, "color": "#27AE60", "label": "Inclusive Regime / High I (Open Tail)"}
    ]
    for r in regimes:
        pdf_vals = truncated_gamma_pdf(x_grid, r["alpha"], r["beta"], r["cap"])
        ax1.plot(x_grid[x_grid <= r["cap"]], pdf_vals[x_grid <= r["cap"]], color=r["color"], linewidth=2.5, label=r["label"])
        ax1.fill_between(x_grid[x_grid <= r["cap"]], pdf_vals[x_grid <= r["cap"]], color=r["color"], alpha=0.15)
    ax1.set_title("Cross-Country Stationary Truncated Gamma Distributions under Variance Caps", fontsize=11, fontweight="bold")
    ax1.set_xlabel("Specialized Knowledge & Economic Complexity Stock (X)", fontsize=10)
    ax1.set_ylabel("Stationary Density P_trunc(X)", fontsize=10)
    ax1.grid(True, linestyle="--", alpha=0.5)
    ax1.legend(frameon=True, fontsize=8.5)
    plt.tight_layout()
    fig1.savefig("figure1_truncated_gamma.png", dpi=300)
    plt.close(fig1)

    print("Simulation execution completed successfully!")
